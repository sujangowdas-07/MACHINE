"use client"

import React from "react"
import { cn } from "@/lib/utils"
import { API_BASE_URL } from "@/lib/config"

type PredictResponse = {
  prediction: "Yes" | "No"
  probability: number // 0..1 -> probability of heart disease "Yes"
  model_version?: string
}

type FormState = {
  age: string
  sex: "male" | "female"
  cp: "0" | "1" | "2" | "3"
  trestbps: string
  chol: string
  fbs: "0" | "1"
  restecg: "0" | "1" | "2"
  thalach: string
  exang: "0" | "1"
  oldpeak: string
  slope: "0" | "1" | "2"
  ca: "0" | "1" | "2" | "3"
  thal: "0" | "1" | "2" | "3"
}

const initialState: FormState = {
  age: "",
  sex: "male",
  cp: "0",
  trestbps: "",
  chol: "",
  fbs: "0",
  restecg: "1",
  thalach: "",
  exang: "0",
  oldpeak: "",
  slope: "1",
  ca: "0",
  thal: "2",
}

export default function HeartForm() {
  const [form, setForm] = React.useState<FormState>(initialState)
  const [loading, setLoading] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)
  const [result, setResult] = React.useState<PredictResponse | null>(null)

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setResult(null)

    // Basic client-side validation
    const requiredNumeric = ["age", "trestbps", "chol", "thalach", "oldpeak"] as const
    for (const key of requiredNumeric) {
      const v = form[key]
      if (v === "" || Number.isNaN(Number(v))) {
        setError(`Please enter a valid number for ${key}.`)
        return
      }
    }

    setLoading(true)
    try {
      const res = await fetch(`${API_BASE_URL}/predict`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          // Backend accepts these names; keep aligned with FastAPI schema
          age: Number(form.age),
          sex: form.sex, // "male" | "female"
          cp: Number(form.cp),
          trestbps: Number(form.trestbps),
          chol: Number(form.chol),
          fbs: Number(form.fbs),
          restecg: Number(form.restecg),
          thalach: Number(form.thalach),
          exang: Number(form.exang),
          oldpeak: Number(form.oldpeak),
          slope: Number(form.slope),
          ca: Number(form.ca),
          thal: Number(form.thal),
        }),
      })
      if (!res.ok) {
        const msg = await res.text()
        throw new Error(msg || "Request failed")
      }
      const data: PredictResponse = await res.json()
      // Normalize bounds
      const prob = Math.max(0, Math.min(1, data.probability ?? 0))
      setResult({ ...data, probability: prob })
    } catch (err: any) {
      setError(err?.message || "An unexpected error occurred.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="rounded-lg border bg-card p-6">
      <form onSubmit={onSubmit} className="grid grid-cols-1 gap-5 md:grid-cols-2">
        {/* Age */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Age</label>
          <input
            required
            inputMode="numeric"
            pattern="[0-9]*"
            value={form.age}
            onChange={(e) => update("age", e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            placeholder="e.g., 54"
            aria-label="Age in years"
          />
        </div>

        {/* Sex */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Sex</label>
          <select
            value={form.sex}
            onChange={(e) => update("sex", e.target.value as FormState["sex"])}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            aria-label="Sex"
          >
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </div>

        {/* Chest Pain Type */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Chest Pain Type (cp)</label>
          <select
            value={form.cp}
            onChange={(e) => update("cp", e.target.value as FormState["cp"])}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            aria-label="Chest Pain Type"
          >
            <option value="0">0: Typical Angina</option>
            <option value="1">1: Atypical Angina</option>
            <option value="2">2: Non-anginal Pain</option>
            <option value="3">3: Asymptomatic</option>
          </select>
        </div>

        {/* Resting Blood Pressure */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Resting Blood Pressure (trestbps)</label>
          <input
            required
            inputMode="numeric"
            pattern="[0-9]*"
            value={form.trestbps}
            onChange={(e) => update("trestbps", e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            placeholder="mm Hg"
            aria-label="Resting Blood Pressure in mm Hg"
          />
        </div>

        {/* Cholesterol */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Serum Cholesterol (chol)</label>
          <input
            required
            inputMode="numeric"
            pattern="[0-9]*"
            value={form.chol}
            onChange={(e) => update("chol", e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            placeholder="mg/dl"
            aria-label="Serum Cholesterol in mg/dl"
          />
        </div>

        {/* Fasting Blood Sugar */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Fasting Blood Sugar &gt; 120 mg/dl (fbs)</label>
          <select
            value={form.fbs}
            onChange={(e) => update("fbs", e.target.value as FormState["fbs"])}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            aria-label="Fasting Blood Sugar"
          >
            <option value="0">0: No</option>
            <option value="1">1: Yes</option>
          </select>
        </div>

        {/* Resting ECG */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Resting ECG (restecg)</label>
          <select
            value={form.restecg}
            onChange={(e) => update("restecg", e.target.value as FormState["restecg"])}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            aria-label="Resting ECG"
          >
            <option value="0">0: Left ventricular hypertrophy</option>
            <option value="1">1: Normal</option>
            <option value="2">2: ST-T wave abnormality</option>
          </select>
        </div>

        {/* Max Heart Rate */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Max Heart Rate (thalach)</label>
          <input
            required
            inputMode="numeric"
            pattern="[0-9]*"
            value={form.thalach}
            onChange={(e) => update("thalach", e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            placeholder="e.g., 150"
            aria-label="Maximum Heart Rate Achieved"
          />
        </div>

        {/* Exercise Induced Angina */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Exercise Induced Angina (exang)</label>
          <select
            value={form.exang}
            onChange={(e) => update("exang", e.target.value as FormState["exang"])}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            aria-label="Exercise Induced Angina"
          >
            <option value="0">0: No</option>
            <option value="1">1: Yes</option>
          </select>
        </div>

        {/* Oldpeak */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">ST Depression (oldpeak)</label>
          <input
            required
            inputMode="decimal"
            value={form.oldpeak}
            onChange={(e) => update("oldpeak", e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            placeholder="e.g., 1.4"
            aria-label="ST depression induced by exercise relative to rest"
          />
        </div>

        {/* Slope */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Slope</label>
          <select
            value={form.slope}
            onChange={(e) => update("slope", e.target.value as FormState["slope"])}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            aria-label="Slope of the peak exercise ST segment"
          >
            <option value="0">0: Upsloping</option>
            <option value="1">1: Flat</option>
            <option value="2">2: Downsloping</option>
          </select>
        </div>

        {/* CA */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Number of Major Vessels Colored (ca)</label>
          <select
            value={form.ca}
            onChange={(e) => update("ca", e.target.value as FormState["ca"])}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            aria-label="Number of major vessels colored by fluoroscopy"
          >
            <option value="0">0</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
        </div>

        {/* Thal */}
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Thalassemia (thal)</label>
          <select
            value={form.thal}
            onChange={(e) => update("thal", e.target.value as FormState["thal"])}
            className="h-10 rounded-md border bg-background px-3 text-sm"
            aria-label="Thalassemia"
          >
            <option value="1">1: Fixed Defect</option>
            <option value="2">2: Normal</option>
            <option value="3">3: Reversible Defect</option>
            <option value="0">0: Unknown</option>
          </select>
        </div>

        <div className="md:col-span-2 mt-2 flex items-center gap-3">
          <button
            type="submit"
            disabled={loading}
            className={cn(
              "h-10 rounded-md px-4 text-sm font-medium",
              "bg-primary text-primary-foreground",
              "disabled:opacity-60",
            )}
          >
            {loading ? "Predicting..." : "Predict"}
          </button>
          <button
            type="button"
            onClick={() => {
              setForm(initialState)
              setResult(null)
              setError(null)
            }}
            className={cn("h-10 rounded-md px-4 text-sm font-medium", "bg-secondary text-secondary-foreground")}
          >
            Reset
          </button>
        </div>
      </form>

      <div className="mt-6" aria-live="polite">
        {error && (
          <div role="alert" className="rounded-md border border-destructive/40 bg-accent p-4 text-sm">
            <strong className="block">Prediction error</strong>
            <span className="text-muted-foreground">{error}</span>
          </div>
        )}

        {result && (
          <div className="rounded-md border bg-card p-4">
            <div className="flex items-start justify-between gap-4">
              <div className="text-sm">
                <div className="font-medium">Heart Disease</div>
                <div className="mt-1 flex items-center gap-2">
                  <span
                    className={cn(
                      "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
                      result.prediction === "Yes"
                        ? "bg-destructive text-destructive-foreground"
                        : "bg-accent text-accent-foreground",
                    )}
                  >
                    {result.prediction === "Yes" ? "Disease Risk" : "No Disease"}
                  </span>
                  {typeof result.model_version === "string" ? (
                    <span className="text-xs text-muted-foreground">model: {result.model_version}</span>
                  ) : null}
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-medium">{(result.probability * 100).toFixed(1)}%</div>
                <div className="text-xs text-muted-foreground">probability</div>
              </div>
            </div>

            <ProbabilityBar probability={result.probability} label={`Probability of "Yes"`} className="mt-3" />
            <p className="mt-2 text-xs text-muted-foreground">
              This is not medical advice. Consult a healthcare professional for diagnosis.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

function ProbabilityBar({
  probability,
  label,
  className,
}: {
  probability: number
  label?: string
  className?: string
}) {
  const pct = Math.round(probability * 100)
  const tone = probability >= 0.5 ? "bg-destructive" : "bg-accent"
  return (
    <div className={cn("w-full", className)}>
      {label ? <div className="mb-1 text-xs text-muted-foreground">{label}</div> : null}
      <div className="h-3 w-full overflow-hidden rounded-md border bg-muted" aria-hidden="true">
        <div
          className={cn("h-full", tone)}
          style={{ width: `${pct}%` }}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={pct}
          role="progressbar"
        />
      </div>
      <span className="mt-1 block text-xs text-muted-foreground" aria-live="polite">
        {pct}%
      </span>
    </div>
  )
}
