# Heart Disease Classification - Full Stack

This project contains:
- Frontend: Next.js (React + Tailwind) app in the repository root (`app/`).
- Backend: FastAPI service under `backend/` exposing POST /predict.

Configure the frontend to call your backend by setting:
- NEXT_PUBLIC_API_BASE_URL (e.g., http://localhost:8000 or your deployed API URL)

Backend expects an artifact at `backend/artifacts/heart_pipeline.joblib` exported from your notebook.
If missing, it trains a small fallback model for demo (not for medical use).
