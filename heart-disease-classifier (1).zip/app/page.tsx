import HeartForm from "@/components/heart-form"

export default function Page() {
  return (
    <main className="min-h-dvh bg-background">
      <section className="mx-auto max-w-3xl px-4 py-10">
        <header className="mb-8">
          <h1 className="text-4xl md:text-5xl font-semibold text-balance">Heart Disease Risk Prediction</h1>
          <p className="mt-3 text-muted-foreground text-pretty">
            Enter your health details to get a machine learning prediction with a clear confidence score.
          </p>
        </header>
        <HeartForm />
      </section>
      <footer className="py-8 text-center text-sm text-muted-foreground">
        Built with FastAPI backend and a trained ML model.
      </footer>
    </main>
  )
}
