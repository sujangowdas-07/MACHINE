Heart Disease Prediction API (FastAPI)

Expected model artifact:
- Place your trained pipeline at artifacts/heart_pipeline.joblib.
- The pipeline should accept either:
  - a 2D numpy array matching feature order:
    ['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal']
    where 'sex' is numeric (1=male, 0=female)
  - OR a pandas DataFrame with those column names.

If no artifact is found at startup, a simple fallback model will be trained using a public heart dataset for demo purposes.

Config (env):
- ALLOWED_ORIGINS: comma-separated origins for CORS (e.g. https://your-frontend.com, http://localhost:3000)
- MODEL_ARTIFACT: override path to model joblib (default artifacts/heart_pipeline.joblib)
