from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator
from typing import Literal, Optional
import os
import joblib
import numpy as np

# Optional: lightweight fallback training if artifact not present
def _load_or_train_pipeline():
    artifact_path = os.environ.get("MODEL_ARTIFACT", "artifacts/heart_pipeline.joblib")
    if os.path.exists(artifact_path):
        try:
            pipeline = joblib.load(artifact_path)
            return pipeline, "artifact"
        except Exception:
            pass

    # Fallback: train a simple model on the UCI Heart Disease dataset (Cleveland)
    try:
        import pandas as pd
        from sklearn.datasets import load_iris  # placeholder import to ensure sklearn works
        from sklearn.linear_model import LogisticRegression
        from sklearn.preprocessing import StandardScaler
        from sklearn.pipeline import Pipeline

        # Minimal public dataset source for heart (small, for demo)
        # You can replace this with your notebook's exact features and preprocessing.
        url = "https://raw.githubusercontent.com/plotly/datasets/master/heart.csv"
        df = pd.read_csv(url)

        # Align columns to common heart dataset fields
        # We'll map to: ['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal']
        # Some CSVs may use different names; adjust as needed.
        expected = ['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal']
        available = [c for c in expected if c in df.columns]
        # Target label often named 'target'
        y_col = 'target' if 'target' in df.columns else None
        if y_col is None or len(available) < 8:
            raise RuntimeError("Dataset schema mismatch for fallback training.")

        X = df[available].copy()
        y = df[y_col].astype(int)

        pipeline = Pipeline(
            steps=[
                ("scaler", StandardScaler(with_mean=True, with_std=True)),
                ("clf", LogisticRegression(max_iter=1000)),
            ]
        )
        pipeline.fit(X, y)

        # Save trained fallback
        os.makedirs(os.path.dirname(artifact_path), exist_ok=True)
        joblib.dump(pipeline, artifact_path)

        return pipeline, "fallback"
    except Exception:
        raise RuntimeError(
            "Model artifact not found and fallback training failed. "
            "Please export your trained pipeline to artifacts/heart_pipeline.joblib."
        )

app = FastAPI(title="Heart Disease Prediction API", version="1.0.0")

# CORS
allowed_origins = os.environ.get("ALLOWED_ORIGINS", "*")
origins = [o.strip() for o in allowed_origins.split(",")] if allowed_origins else ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_methods=["POST", "OPTIONS"],
    allow_headers=["*"],
)

SexStr = Literal["male", "female"]

class PredictRequest(BaseModel):
    age: int = Field(..., ge=1, le=120)
    sex: SexStr
    cp: int = Field(..., ge=0, le=3)
    trestbps: int = Field(..., ge=50, le=300)
    chol: int = Field(..., ge=80, le=700)
    fbs: int = Field(..., ge=0, le=1)
    restecg: int = Field(..., ge=0, le=2)
    thalach: int = Field(..., ge=50, le=250)
    exang: int = Field(..., ge=0, le=1)
    oldpeak: float = Field(..., ge=0.0, le=10.0)
    slope: int = Field(..., ge=0, le=2)
    ca: int = Field(..., ge=0, le=4)
    thal: int = Field(..., ge=0, le=3)

    @field_validator("sex")
    @classmethod
    def normalize_sex(cls, v: SexStr) -> SexStr:
        return v.lower()  # "male" | "female"

class PredictResponse(BaseModel):
    prediction: Literal["Yes", "No"]
    probability: float
    model_version: Optional[str] = None

# Lazy singleton
_model = None
_model_origin = None

def _ensure_model():
    global _model, _model_origin
    if _model is None:
        _model, _model_origin = _load_or_train_pipeline()

@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    try:
        _ensure_model()
        # Arrange features to match training order
        # If you trained a pipeline in your notebook, ensure the exact same order and preprocessing.
        X = np.array(
            [[
                req.age,
                1 if req.sex == "male" else 0,
                req.cp,
                req.trestbps,
                req.chol,
                req.fbs,
                req.restecg,
                req.thalach,
                req.exang,
                req.oldpeak,
                req.slope,
                req.ca,
                req.thal,
            ]],
            dtype=float,
        )

        # For artifact from notebook: prefer a pipeline that can accept a DataFrame with column names
        try:
            # Attempt DataFrame predict_proba if the pipeline supports named columns
            import pandas as pd
            cols = ['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal']
            X_df = pd.DataFrame(X, columns=cols)
            proba = getattr(_model, "predict_proba")(X_df)[0, 1]
        except Exception:
            proba = getattr(_model, "predict_proba")(X)[0, 1]

        pred = "Yes" if proba >= 0.5 else "No"
        return PredictResponse(
            prediction=pred,
            probability=float(proba),
            model_version=_model_origin,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
